#!/bin/bash -l
#PBS -l nodes=1:broadwell:ppn=28
#PBS -N p2
#PBS -M -m n
#PBS -q mem512

MOLPRO=/home/trushin/Molpro-2020.1-develop/Molpro-dev/
num=1
export OMP_NUM_THREADS=${num}
export MKL_NUM_THREADS=${num}
export OMP_STACKSIZE=3000M
ulimit -s unlimited
export MV2_CPU_MAPPING=0-$(( ${num} - 1))
cd $PBS_O_WORKDIR
uniq $PBS_NODEFILE > $PBS_O_WORKDIR/machines_jobid
export FI_PROVIDER=tcp

TMPDIR=/scratch/trushin/${PBS_JOBID}

mpirun -n 1 -ppn 1 -f machines_jobid  $MOLPRO/molpro.exe -t 16 --no-xml-output --no-helper-server -d $TMPDIR < input 1> $PBS_O_WORKDIR/output 2> $PBS_O_WORKDIR/error

rm *.wfu *vxdiff machines_jobid
scp $TMPDIR/* tcsv019:$PBS_O_WORKDIR
